# Simple Database System
Aplikasi untuk implementasi materi GUI, Exception, dan Pemograman Dasar dalam Pemograman Berorientasi Objek menggunakan Bahasa Pemograman Java

### Author
- Nama  : Alfian Badrul Isnan
- NPM   : 1808148643

### Source Code
- DataSiswa.java (database method)
- Rapor.java (main method)
- Rapor.form (form GUI)

### How to user
- Run by runApp.bat
- batch command `cd out\production\DataList\` then `java Rapor`
- Load to Intellij IDE